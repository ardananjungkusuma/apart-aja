<script type="text/javascript">
    $(document).ready(function() {
        $('#listTransaksiPembelian').DataTable();
        $('#listDaftarPenghuni').DataTable();
        $('#listDaftarPenghuni').DataTable();
    });
</script>
<script src="<?= base_url() ?>assets/js/bootstrap.min.js"></script>
<script src="<?= base_url() ?>assets/js/bootstrap.bundle.min.js"></script>
</body>

</html>