</div>
</div>
</div>
<hr>
<section class="mbr-section mbr-section--relative mbr-section--fixed-size" id="contacts3-v" data-rv-view="140" style="background-color: rgb(255, 255, 255);">

	<div class="mbr-section__container container">
		<div class="mbr-contacts mbr-contacts--wysiwyg row" style="padding-top: 30px; padding-bottom: 45px;">
			<div class="col-sm-8">
				<div class="row">
					<div class="col-sm-6">
						<p class="mbr-contacts__text"><strong>ALAMAT</strong><br>Jl Soekarno Hatta,Kecamatan Lowokwaru&nbsp;<br>No. 310 Kota Malang<br><br>
							<strong>CONTACTS</strong><br>
							Email: contact@apartaja.com<br>
							Phone: +62(852571235)<br>
					</div>
					<div class="col-sm-6">
						<p class="mbr-contacts__text"><strong>Payment Support</strong><br><img src="<?= base_url(); ?>assets/images/logo-bca.png" style="width:50px"> <img src="<?= base_url(); ?>assets/images/BNI_logo.svg" style="width:50px">&nbsp;
					</div>
					<div class="col-sm-6">
						<ul class="mbr-contacts__list"></ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	</div>
</section>
<hr>
<center>&copy;<?= date('Y') ?>.Apart Aja, Inc. All Rights Reserved.</center>


<script src="<?= base_url(); ?>assets/web/assets/jquery/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>
<script src="<?= base_url(); ?>assets/smooth-scroll/smooth-scroll.js"></script>
<script src="<?= base_url(); ?>assets/jarallax/jarallax.js"></script>
<script src="<?= base_url(); ?>assets/masonry/masonry.pkgd.min.js"></script>
<script src="<?= base_url(); ?>assets/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="<?= base_url(); ?>assets/bootstrap-carousel-swipe/bootstrap-carousel-swipe.js"></script>
<script src="<?= base_url(); ?>assets/mobirise/js/script.js"></script>
<script src="<?= base_url(); ?>assets/mobirise-gallery/script.js"></script>
<script src="<?= base_url(); ?>assets/formoid/formoid.min.js"></script>
<script src="<?= base_url(); ?>assets/smooth-scroll/smooth-scroll.js"></script>
<script src="<?= base_url(); ?>assets/jarallax/jarallax.js"></script>
<script src="<?= base_url(); ?>assets/masonry/masonry.pkgd.min.js"></script>
<script src="<?= base_url(); ?>assets/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="<?= base_url(); ?>assets/bootstrap-carousel-swipe/bootstrap-carousel-swipe.js"></script>
<script src="<?= base_url(); ?>assets/mobirise/js/script.js"></script>
<script src="<?= base_url(); ?>assets/mobirise-gallery/script.js"></script>
<script src="<?= base_url(); ?>assets/formoid/formoid.min.js"></script>
<script src="<?= base_url(); ?>assets/web/assets/jquery/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/bootstrap/js/bootstrap.min.js"></script>


</body>

</html>