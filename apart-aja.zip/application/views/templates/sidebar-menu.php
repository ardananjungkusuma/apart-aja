<div class="container" style="padding: 20px; margin: 10 px auto; margin-left: 220px; margin-right: auto;margin-top:50px;">
    <div class="row" style="margin-top: 80px;">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header" style="background:#e32447;text-align: center;color:white;font-weight: bolder">
                    User Menu
                </div>
                <ul class="list-group list-group-flush">
                    <a href="<?= base_url() ?>user/profile" style="text-decoration: none;color: black" id="itemmenu" class="list-group-item">Profile</a>
                    <a href="<?= base_url() ?>apartemen/apartemenAnda" style="text-decoration: none;color: black" id="itemmenu" class="list-group-item">Apartemen Anda</a>
                    <a href="<?= base_url() ?>transaksi/transaksiAnda" style="text-decoration: none;color: black" id="itemmenu" class="list-group-item">Transaksi Pembelian</a>
                    <a href="<?= base_url() ?>kritiksaran/kritikSaranAnda" style="text-decoration: none;color: black" id="itemmenu" class="list-group-item">Kritik & Saran</a>
                </ul>
            </div>
        </div>
        <div class="col-md-9">