# Apart Aja

## 🏨 Apa itu Apart Aja?

Platform Website untuk jual beli apartemen. Untuk membantu para pemilik apartemen mempromosikan apartemen dan memudahkan para calon pembeli apartemen untuk membeli maupun untuk sekedar melihat apartemen baik secara exterior maupun interior.

## 😺 Syarat yang diperlukan

- Versi PHP7 keatas.
- Internet ( Ada beberapa CDN Bootstrap )
- XAMPP ( Atau Web Server lain )
- Web Browser

## 🌌 License

- Copyright © 2020 Ardan Anjung Kusuma
- **Apart Aja is open-sourced software licensed under the MIT license**

---

**Made with ❤️ by Ardan Anjung Kusuma**
